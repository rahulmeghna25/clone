from pyrogram import filters
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup
from RishuMusic import app
from config import BOT_USERNAME
from RishuMusic.utils.errors import capture_err
import httpx 
from pyrogram.types import InlineKeyboardButton, InlineKeyboardMarkup

start_txt = """
**
┌┬─────────────────⦿
│├─────────────────╮
│├ ᴛɢ ɴᴀᴍᴇ - D E M O N
│├ ʀᴇᴀʟ ɴᴀᴍᴇ - D E M O N
│├─────────────────╯
├┼─────────────────⦿
├┤~ @ABOUT_DEMONPAPATHUMAHRA
├┤~ @DEMONPAPATHUMAHRA
├┤~ @DEMONPAPATHUMAHRA
├┼─────────────────⦿
│├─────────────────╮
│├OWNER│ @DEMONPAPATHUMAHRA
│├─────────────────╯
└┴─────────────────⦿
**
"""




@app.on_message(filters.command("owner"))
async def start(_, msg):
    buttons = [
        [ 
          InlineKeyboardButton("D E M O N", url=f"https://t.me/DEMONPAPATHUMAHRA")
        ],
        [
          InlineKeyboardButton("ＨＥＬＰ", url="https://t.me/DEMONPAPATHUMAHRA"),
          InlineKeyboardButton("ＲＥＰＯ", url="https://t.me/DEMONPAPATHUMAHRA"),
          ],
               [
                InlineKeyboardButton(" ＮＥＴＷＯＲＫ", url=f"https://t.me/DEMONPAPATHUMAHRA"),
],
[
InlineKeyboardButton("ＯＦＦＩＣＩＡＬ ＢＯＴ", url=f"https://t.me/officialmeghna007"),

        ]]
    
    reply_markup = InlineKeyboardMarkup(buttons)
    
    await msg.reply_photo(
        photo="https://files.catbox.moe/qu0hhu.jpg",
        caption=start_txt,
        reply_markup=reply_markup
    )
